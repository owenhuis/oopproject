﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pokemonBattleSim.classes
{
    internal class Bulbasaur : Pokemon
    {
        public Bulbasaur(string nickname) : base(nickname, "Grass", "Fire", "Bulbasaur")
        {

        }
    }
}
