﻿using System;

namespace pokemonBattleSim.classes
{
    class Charmander: Pokemon
    {
        public Charmander(string nickname) : base(nickname, "Fire", "Water", "Charmander")
        {
        }
    }
}
